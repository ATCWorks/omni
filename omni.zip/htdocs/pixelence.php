<?php
// Oturum işlemleri başlatılıyor
session_start();

// KULLANICI GİRİŞ KONTROLÜ
// Not: $_SESSION['user_logged_in'] kısmını kendi oturum değişkeninize göre düzenleyin.
// Örneğin: $_SESSION['user_id'] veya benzeri.
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    // Kullanıcı giriş yapmamışsa login.php'ye yönlendir
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OMNi Forum - Pixelence Intro</title>
    <style>
        /* Temel Reset ve Fontlar */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            overflow: hidden; /* Scroll barlarını gizle */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            background-color: #000; /* Video yüklenmezse siyah kalsın */
        }

        /* Arka Plan Videosu Ayarları */
        #bg-video {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1; /* İçeriğin arkasında kalması için */
            object-fit: cover; /* Ekranı doldurması için */
            filter: brightness(0.6); /* Yazıların okunması için videoyu hafif karart */
        }

        /* Ana İçerik Konteyneri */
        .content-container {
            text-align: center;
            z-index: 1;
            opacity: 0; /* Animasyon için başlangıçta gizli */
            animation: fadeIn 2s ease-in-out forwards;
        }

        /* Logo ve Başlık Alanı */
        .logo-title-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px; /* Logo ve yazı arası boşluk */
            margin-bottom: 15px;
        }

        .omni-logo {
            width: 80px; /* Logo boyutu - ihtiyaca göre ayarlayın */
            height: auto;
            filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.3));
        }

        .main-title {
            font-size: 4rem;
            font-weight: 700;
            letter-spacing: 2px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
            margin: 0;
        }

        /* Slogan */
        .slogan {
            font-size: 1.5rem;
            font-weight: 300;
            letter-spacing: 1px;
            margin-top: 10px;
            opacity: 0.9;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.8);
        }

        /* En Alttaki Footer */
        .footer-credit {
            position: absolute;
            bottom: 30px;
            font-size: 0.9rem;
            opacity: 0.7;
            font-family: 'Courier New', Courier, monospace; /* Kodlama hissiyatı için */
            letter-spacing: 1px;
            z-index: 1;
        }

        /* Giriş Animasyonu */
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        /* Mobil Uyumluluk */
        @media (max-width: 768px) {
            .logo-title-wrapper {
                flex-direction: column;
            }
            .main-title {
                font-size: 2.5rem;
            }
            .slogan {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

    <!-- Arka Plan Videosu -->
    <video autoplay muted loop id="bg-video">
        <source src="pixelence1.mp4" type="video/mp4">
        Tarayıcınız video etiketini desteklemiyor.
    </video>

    <!-- Ana İçerik -->
    <div class="content-container">
        <div class="logo-title-wrapper">
            <!-- Logo -->
            <img src="omnilogo.png" alt="OMNi Logo" class="omni-logo">
            <!-- Başlık -->
            <h1 class="main-title">OMNi Forum</h1>
        </div>
        <!-- Alt Slogan -->
        <p class="slogan">The Power is in your hands.</p>
    </div>

    <!-- Alt Bilgi -->
    <div class="footer-credit">A Moca Dev.S Project</div>

    <script>
        // 7 Saniye (7000 milisaniye) sonra yönlendirme
        setTimeout(function() {
            window.location.href = 'index.php';
        }, 7000);
    </script>

</body>
</html>